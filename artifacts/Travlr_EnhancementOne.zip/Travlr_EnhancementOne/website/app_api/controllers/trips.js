const mongoose = require('mongoose');
require('../models/travlr');

const Trip = mongoose.model('trips');

const sendJSONresponse = (res, status, content) => {
  res.status(status);
  res.json(content);
};

const validateTrip = (trip) => {
  const errors = [];

  if (!trip.code || trip.code.trim() === '') errors.push('Trip code is required');
  if (!trip.name || trip.name.trim() === '') errors.push('Trip name is required');
  if (!trip.length || trip.length.trim() === '') errors.push('Trip length is required');
  if (!trip.start || isNaN(Date.parse(trip.start))) errors.push('A valid start date is required');
  if (!trip.resort || trip.resort.trim() === '') errors.push('Resort is required');

  if (!trip.perPerson || isNaN(Number(trip.perPerson)) || Number(trip.perPerson) < 0) {
    errors.push('Per-person price must be a valid positive number');
  }

  if (!trip.image || trip.image.trim() === '') errors.push('Image filename is required');

  if (!trip.description || trip.description.trim().length < 10) {
    errors.push('Description must be at least 10 characters');
  }

  return errors;
};

// GET /api/trips
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).lean();
    return sendJSONresponse(res, 200, trips);
  } catch (err) {
    return sendJSONresponse(res, 500, { message: err.message });
  }
};

// GET /api/trips/:tripCode
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).lean();

    if (!trip) {
      return sendJSONresponse(res, 404, { message: 'Trip not found' });
    }

    return sendJSONresponse(res, 200, trip);
  } catch (err) {
    return sendJSONresponse(res, 500, { message: err.message });
  }
};

// POST /api/trips
const tripsAdd = async (req, res) => {
  try {
    const errors = validateTrip(req.body);

    if (errors.length > 0) {
      return sendJSONresponse(res, 400, {
        message: 'Validation failed',
        errors
      });
    }

    const newTrip = await Trip.create({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });

    return sendJSONresponse(res, 201, newTrip);
  } catch (err) {
    return sendJSONresponse(res, 400, { message: err.message });
  }
};

// PUT /api/trips/:tripCode
const tripsUpdateByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode });

    if (!trip) {
      return sendJSONresponse(res, 404, { message: 'Trip not found' });
    }

    const updatedData = {
      code: trip.code,
      name: req.body.name ?? trip.name,
      length: req.body.length ?? trip.length,
      start: req.body.start ?? trip.start,
      resort: req.body.resort ?? trip.resort,
      perPerson: req.body.perPerson ?? trip.perPerson,
      image: req.body.image ?? trip.image,
      description: req.body.description ?? trip.description
    };

    const errors = validateTrip(updatedData);

    if (errors.length > 0) {
      return sendJSONresponse(res, 400, {
        message: 'Validation failed',
        errors
      });
    }

    trip.name = updatedData.name;
    trip.length = updatedData.length;
    trip.start = updatedData.start;
    trip.resort = updatedData.resort;
    trip.perPerson = updatedData.perPerson;
    trip.image = updatedData.image;
    trip.description = updatedData.description;

    const updatedTrip = await trip.save();
    return sendJSONresponse(res, 200, updatedTrip);
  } catch (err) {
    return sendJSONresponse(res, 400, { message: err.message });
  }
};

// DELETE /api/trips/:tripCode
const tripsDeleteByCode = async (req, res) => {
  try {
    const result = await Trip.deleteOne({ code: req.params.tripCode });

    if (result.deletedCount === 0) {
      return sendJSONresponse(res, 404, { message: 'Trip not found' });
    }

    return res.status(204).send();
  } catch (err) {
    return sendJSONresponse(res, 500, { message: err.message });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAdd,
  tripsUpdateByCode,
  tripsDeleteByCode
};