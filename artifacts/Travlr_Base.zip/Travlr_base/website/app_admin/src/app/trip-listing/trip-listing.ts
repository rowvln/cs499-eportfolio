import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { timeout } from 'rxjs/operators';

import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';
import { TripCard } from '../trip-card/trip-card';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
})
export class TripListing implements OnInit {
  trips: Trip[] = [];
  loading = true;
  error = '';

  constructor(
    private tripDataService: TripDataService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.loading = true;
    this.error = '';

    this.tripDataService.getTrips()
      .pipe(timeout(5000))
      .subscribe({
        next: (data) => {
          console.log('Trips loaded:', data);
          this.trips = data;
          this.loading = false;
          this.cdr.detectChanges();
        },
        error: (err) => {
          console.error('Trips failed:', err);
          this.error = 'Failed to load trips';
          this.loading = false;
          this.cdr.detectChanges();
        }
      });
  }

  onDeleted(): void {
    this.loadTrips();
  }
}