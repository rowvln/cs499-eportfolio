import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css',
})
export class AddTrip {
  trip: Trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  saving = false;
  error = '';
  submitted = false;

  constructor(private tripDataService: TripDataService, private router: Router) {}

  private validateTrip(): string[] {
    const errors: string[] = [];

    if (!this.trip.code.trim()) errors.push('Trip code is required.');
    if (!this.trip.name.trim()) errors.push('Trip name is required.');
    if (!this.trip.length.trim()) errors.push('Trip length is required.');
    if (!this.trip.start) errors.push('Start date is required.');
    if (!this.trip.resort.trim()) errors.push('Resort is required.');

    if (!this.trip.perPerson || Number(this.trip.perPerson) < 0) {
      errors.push('Per-person price must be valid.');
    }

    if (!this.trip.image.trim()) errors.push('Image filename is required.');

    if (!this.trip.description || this.trip.description.trim().length < 10) {
      errors.push('Description must be at least 10 characters.');
    }

    return errors;
  }

  onSubmit(): void {
    this.submitted = true;
    this.error = '';

    const validationErrors = this.validateTrip();

    if (validationErrors.length > 0) {
      this.error = validationErrors.join(' ');
      return;
    }

    this.saving = true;

    this.tripDataService.addTrip(this.trip).subscribe({
      next: () => {
        this.saving = false;
        this.router.navigate(['/trips']);
      },
      error: (err) => {
        console.error('Error adding trip:', err);

        this.error =
          err.error?.errors?.join(' ') ||
          err.error?.message ||
          'Failed to add trip.';

        this.saving = false;
      }
    });
  }
}