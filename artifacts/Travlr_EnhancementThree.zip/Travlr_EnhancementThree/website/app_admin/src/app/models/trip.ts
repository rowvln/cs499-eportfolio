export interface Trip {
  code: string;
  name: string;
  length: string;
  start: string;
  resort: string;

  // perPerson can come from form input as a string, but the database stores it as a number.
  perPerson: number | string;

  image: string;
  description: string;
}