const mongoose = require('mongoose');

/**
 * CS-499 Enhancement Three
 * Database validation, indexing, and schema consistency improvements.
 */

const tripSchema = new mongoose.Schema(
  {
    // Added stronger schema rules so bad trip data is caught before it reaches MongoDB.
    code: {
      type: String,
      required: [true, 'Trip code is required'],
      trim: true,
      uppercase: true
    },

    name: {
      type: String,
      required: [true, 'Trip name is required'],
      trim: true,
      minlength: [3, 'Trip name must be at least 3 characters']
    },

    length: {
      type: String,
      required: [true, 'Trip length is required'],
      trim: true
    },

    start: {
      type: Date,
      required: [true, 'Start date is required']
    },

    resort: {
      type: String,
      required: [true, 'Resort is required'],
      trim: true
    },

    perPerson: {
      type: Number,
      required: [true, 'Per-person price is required'],
      min: [0, 'Per-person price cannot be negative']
    },

    image: {
      type: String,
      required: [true, 'Image filename is required'],
      trim: true
    },

    description: {
      type: String,
      required: [true, 'Description is required'],
      trim: true,
      minlength: [10, 'Description must be at least 10 characters']
    }
  },

  // Timestamps help track when trips are created or updated.
  {
    timestamps: true
  }
);

// Text index supports the search feature added in Enhancement Two.
tripSchema.index({
  name: 'text',
  description: 'text',
  resort: 'text'
});

// These indexes support faster lookups, sorting, and duplicate prevention.
tripSchema.index({ code: 1 }, { unique: true });
tripSchema.index({ start: 1 });
tripSchema.index({ perPerson: 1 });

module.exports =
  mongoose.models.trips ||
  mongoose.model('trips', tripSchema);