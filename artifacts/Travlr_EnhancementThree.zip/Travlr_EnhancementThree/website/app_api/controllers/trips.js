const mongoose = require('mongoose');
require('../models/travlr');

const Trip = mongoose.model('trips');

/**
 * CS-499 Enhancement Three
 * Database validation, indexing, query optimization, and consistent error handling improvements.
 */

// Reused response helper so API responses stay consistent.
const sendJSONresponse = (res, status, content) => {
  res.status(status).json(content);
};

// Centralized database error handling so validation and duplicate errors are easier to manage.
const handleDatabaseError = (res, err) => {
  if (err.name === 'ValidationError') {
    return sendJSONresponse(res, 400, {
      message: 'Validation failed',
      errors: Object.values(err.errors).map((error) => error.message)
    });
  }

  if (err.code === 11000) {
    return sendJSONresponse(res, 409, {
      message: 'Duplicate trip code',
      errors: ['A trip with this code already exists.']
    });
  }

  return sendJSONresponse(res, 500, {
    message: 'Database error',
    error: err.message
  });
};

// Normalize input before saving so database records stay consistent.
const normalizeTripInput = (body) => ({
  code: body.code?.trim().toUpperCase(),
  name: body.name?.trim(),
  length: body.length?.trim(),
  start: body.start,
  resort: body.resort?.trim(),
  perPerson: Number(body.perPerson),
  image: body.image?.trim(),
  description: body.description?.trim()
});

// Limit pagination values so users cannot request an unreasonable amount of data at once.
const getPaginationOptions = (query) => {
  const page = Math.max(parseInt(query.page || '1', 10), 1);
  const limit = Math.min(Math.max(parseInt(query.limit || '6', 10), 1), 25);

  return { page, limit };
};

// Only allow approved sort fields to avoid unsafe or unexpected database queries.
const getSortOptions = (query) => {
  const allowedSortFields = ['start', 'name', 'perPerson'];
  const sortBy = allowedSortFields.includes(query.sortBy)
    ? query.sortBy
    : 'start';

  const sortOrder = query.sortOrder === 'desc' ? -1 : 1;

  return { [sortBy]: sortOrder };
};

// GET /api/trips
const tripsList = async (req, res) => {
  try {
    // Search, sort, and pagination work together so the API can scale better.
    const { page, limit } = getPaginationOptions(req.query);
    const sortOptions = getSortOptions(req.query);

    const search = req.query.search?.trim() || '';

    const dbQuery = search
      ? {
          $text: {
            $search: search
          }
        }
      : {};

    const total = await Trip.countDocuments(dbQuery);

    const trips = await Trip.find(dbQuery)
      .sort(sortOptions)
      .skip((page - 1) * limit)
      .limit(limit)
      .lean();

    return sendJSONresponse(res, 200, {
      trips,
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    });
  } catch (err) {
    return handleDatabaseError(res, err);
  }
};

// GET /api/trips/:tripCode
const tripsFindByCode = async (req, res) => {
  try {
    // Convert trip codes to uppercase so lookups stay consistent.
    const tripCode = req.params.tripCode.trim().toUpperCase();

    const trip = await Trip.findOne({ code: tripCode }).lean();

    if (!trip) {
      return sendJSONresponse(res, 404, {
        message: 'Trip not found'
      });
    }

    return sendJSONresponse(res, 200, trip);
  } catch (err) {
    return handleDatabaseError(res, err);
  }
};

// POST /api/trips
const tripsAdd = async (req, res) => {
  try {
    const tripData = normalizeTripInput(req.body);

    const newTrip = await Trip.create(tripData);

    return sendJSONresponse(res, 201, newTrip);
  } catch (err) {
    return handleDatabaseError(res, err);
  }
};

// PUT /api/trips/:tripCode
const tripsUpdateByCode = async (req, res) => {
  try {
    // Convert trip codes to uppercase so lookups stay consistent.
    const tripCode = req.params.tripCode.trim().toUpperCase();

    const existingTrip = await Trip.findOne({ code: tripCode });

    if (!existingTrip) {
      return sendJSONresponse(res, 404, {
        message: 'Trip not found'
      });
    }

    const updatedData = normalizeTripInput({
      code: existingTrip.code,
      name: req.body.name ?? existingTrip.name,
      length: req.body.length ?? existingTrip.length,
      start: req.body.start ?? existingTrip.start,
      resort: req.body.resort ?? existingTrip.resort,
      perPerson: req.body.perPerson ?? existingTrip.perPerson,
      image: req.body.image ?? existingTrip.image,
      description: req.body.description ?? existingTrip.description
    });

    // runValidators makes sure updates follow the same schema rules as new records.
    const updatedTrip = await Trip.findOneAndUpdate(
      { code: tripCode },
      updatedData,
      {
        new: true,
        runValidators: true
      }
    );

    return sendJSONresponse(res, 200, updatedTrip);
  } catch (err) {
    return handleDatabaseError(res, err);
  }
};

// DELETE /api/trips/:tripCode
const tripsDeleteByCode = async (req, res) => {
  try {
    // Convert trip codes to uppercase so lookups stay consistent.
    const tripCode = req.params.tripCode.trim().toUpperCase();

    const result = await Trip.deleteOne({ code: tripCode });

    if (result.deletedCount === 0) {
      return sendJSONresponse(res, 404, {
        message: 'Trip not found'
      });
    }

    return res.status(204).send();
  } catch (err) {
    return handleDatabaseError(res, err);
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAdd,
  tripsUpdateByCode,
  tripsDeleteByCode
};