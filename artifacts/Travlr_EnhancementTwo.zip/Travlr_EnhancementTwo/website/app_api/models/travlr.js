const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
  code: { type: String, required: true, index: true },
  name: { type: String, required: true, index: true },
  length: { type: String, required: true },
  start: { type: Date, required: true },
  resort: { type: String, required: true },
  perPerson: { type: String, required: true },
  image: { type: String, required: true },
  description: { type: String, required: true }
});

// Enhancement Two:
// Text indexes allow MongoDB to perform faster searches instead of manually scanning every trip document.
tripSchema.index({
  name: 'text',
  description: 'text',
  resort: 'text'
});

// Enhancement Two:
// Additional indexes improve sorting performance when trips are ordered by date or price.
tripSchema.index({ start: 1 });
tripSchema.index({ perPerson: 1 });

// Register once (prevents OverwriteModelError)
module.exports =
  mongoose.models.trips ||
  mongoose.model('trips', tripSchema);