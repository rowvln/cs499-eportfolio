import { Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

import { Trip } from '../models/trip';

export interface TripResponse {
  trips: Trip[];
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  private apiBaseUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  // Retrieves trips using search, sorting, and pagination to reduce unnecessary processing on the frontend.
  getTrips(
    page = 1,
    limit = 6,
    search = '',
    sortBy = 'start',
    sortOrder = 'asc'
  ): Observable<TripResponse> {

    const params = new HttpParams()
      .set('page', page)
      .set('limit', limit)
      .set('search', search)
      .set('sortBy', sortBy)
      .set('sortOrder', sortOrder);

    return this.http
      .get<TripResponse>(
        `${this.apiBaseUrl}/trips`,
        { params }
      )
      .pipe(
        // Cache the most recent result to avoid unnecessary duplicate API requests.
        shareReplay(1)
      );
  }

  // Retrieves one trip by trip code.
  getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(
      `${this.apiBaseUrl}/trips/${tripCode}`
    );
  }

  // Sends a new trip to the protected backend API.
  addTrip(trip: Trip): Observable<Trip> {
    return this.http.post<Trip>(
      `${this.apiBaseUrl}/trips`,
      trip
    );
  }

  // Updates an existing trip through the protected backend API.
  updateTrip(
    tripCode: string,
    trip: Trip
  ): Observable<Trip> {
    return this.http.put<Trip>(
      `${this.apiBaseUrl}/trips/${tripCode}`,
      trip
    );
  }

  // Deletes a trip through the protected backend API.
  deleteTrip(tripCode: string): Observable<void> {
    return this.http.delete<void>(
      `${this.apiBaseUrl}/trips/${tripCode}`
    );
  }
}