import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { timeout } from 'rxjs/operators';

import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css',
})
export class EditTrip implements OnInit {
  trip?: Trip;

  loading = true;
  saving = false;
  error = '';
  submitted = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripDataService: TripDataService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');

    if (!tripCode) {
      this.error = 'No trip code provided';
      this.loading = false;
      this.cdr.detectChanges();
      return;
    }

    this.tripDataService.getTrip(tripCode)
      .pipe(timeout(5000))
      .subscribe({
        next: (data) => {
          this.trip = data;
          this.loading = false;
          this.cdr.detectChanges();
        },
        error: (err) => {
          console.error('Trip load failed:', err);
          this.error = 'Failed to load trip';
          this.loading = false;
          this.cdr.detectChanges();
        }
      });
  }

  private validateTrip(): string[] {
    const errors: string[] = [];

    if (!this.trip) {
      errors.push('Trip data is missing.');
      return errors;
    }

    if (!this.trip.name.trim()) errors.push('Trip name is required.');
    if (!this.trip.length.trim()) errors.push('Trip length is required.');
    if (!this.trip.start) errors.push('Start date is required.');
    if (!this.trip.resort.trim()) errors.push('Resort is required.');

    if (!this.trip.perPerson || Number(this.trip.perPerson) < 0) {
      errors.push('Per-person price must be valid.');
    }

    if (!this.trip.image.trim()) errors.push('Image filename is required.');

    if (!this.trip.description || this.trip.description.trim().length < 10) {
      errors.push('Description must be at least 10 characters.');
    }

    return errors;
  }

  onSubmit(): void {
    if (!this.trip) return;

    this.submitted = true;
    this.error = '';

    const validationErrors = this.validateTrip();

    if (validationErrors.length > 0) {
      this.error = validationErrors.join(' ');
      return;
    }

    this.saving = true;

    this.tripDataService.updateTrip(this.trip.code, this.trip).subscribe({
      next: () => {
        this.saving = false;
        this.router.navigate(['/trips']);
      },
      error: (err) => {
        console.error(err);
        this.error = err.error?.errors?.join(' ') || 'Failed to update trip.';
        this.saving = false;
      },
    });
  }
}