import { Component, OnInit, ChangeDetectorRef } from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { timeout } from 'rxjs/operators';

import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';
import { TripCard } from '../trip-card/trip-card';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    TripCard
  ],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
})
export class TripListing implements OnInit {

  trips: Trip[] = [];

  loading = true;
  error = '';

  // Search term used to filter trip results.
  searchTerm = '';

  // Sorting configuration.
  sortBy = 'start';
  sortOrder = 'asc';

  // Pagination values.
  page = 1;
  limit = 6;
  totalPages = 1;

  constructor(
    private tripDataService: TripDataService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  // Retrieves trips using backend search,
  // sorting, and pagination parameters.
  loadTrips(): void {

    this.loading = true;
    this.error = '';

    this.tripDataService
      .getTrips(
        this.page,
        this.limit,
        this.searchTerm,
        this.sortBy,
        this.sortOrder
      )
      .pipe(timeout(5000))
      .subscribe({

        next: (response) => {

          console.log(
            'Trips loaded:',
            response
          );

          this.trips =
            response.trips;

          this.totalPages =
            response.totalPages;

          this.loading = false;

          this.cdr.detectChanges();
        },

        error: (err) => {

          console.error(
            'Trips failed:',
            err
          );

          this.error =
            'Failed to load trips';

          this.loading = false;

          this.cdr.detectChanges();
        }
      });
  }

  // Refresh results whenever the user searches.
  onSearchChange(): void {

    this.page = 1;

    this.loadTrips();
  }

  // Refresh results whenever sorting changes.
  onSortChange(): void {

    this.page = 1;

    this.loadTrips();
  }

  // Loads the next page of results.
  nextPage(): void {

    if (this.page < this.totalPages) {

      this.page++;

      this.loadTrips();
    }
  }

  // Loads the previous page of results.
  previousPage(): void {

    if (this.page > 1) {

      this.page--;

      this.loadTrips();
    }
  }

  // Refreshes the list after a trip is deleted.
  onDeleted(): void {
    this.loadTrips();
  }
}