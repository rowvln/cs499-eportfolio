// app_server/controllers/travel.js
// Public site pulls trip data from REST API

const travel = async (req, res) => {
  const tripsEndpoint = 'http://localhost:3000/api/trips?limit=100';
  const options = {
    method: 'GET',
    headers: {
      'Accept': 'application/json'
    }
  };

  try {
    const response = await fetch(tripsEndpoint, options);

    // If API returns an error status, pass it through.
    if (!response.ok) {
      return res.status(response.status).send(`API error: ${response.status}`);
    }

    const json = await response.json();

    // Enhancement Two:
    // The API now returns an object with trips and pagination data, so the public travel page needs to read the trips array from json.trips.
    const trips = Array.isArray(json)
      ? json
      : json.trips;

    if (!Array.isArray(trips)) {
      return res.status(500).send('API did not return a valid trips array.');
    }

    if (trips.length === 0) {
      return res.status(404).send('No trips found in the database.');
    }

    return res.render('travel', {
      title: 'Travlr Getaways',
      trips
    });
  } catch (err) {
    return res.status(500).send(err.message);
  }
};

module.exports = {
  travel
};